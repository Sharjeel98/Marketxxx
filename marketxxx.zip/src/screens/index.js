import Home from './Home';
import Cart from './Cart';
import Onboarding1 from './Onboarding1';
import Onboarding2 from './Onboarding2';

export {Home, Cart, Onboarding1, Onboarding2};
