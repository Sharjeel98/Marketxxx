import {App} from './src/routes/index';

export default App;
